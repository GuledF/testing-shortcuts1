from tkinter import *
import os

root = Tk()

root.configure(bg="dark grey")
root.geometry("400x300")
root.resizable(width=False, height=False)


def launch1():
   os.system("EoCApp2020.LNK")


frame1 = Frame(root, width=200, height=100, bg="blue")
frame1.pack(fill="both")
frame2 = Frame(root, width=100, height=100, bg="blue")
frame2.pack(fill="both")
frame3 = Frame(root, width=200, height=200, bg="blue")
frame3.pack(fill="both")


word1 = Label(frame2, text="Click the button under to Launch Divinity 2:", bg="black", fg="white")
word1.pack(side=TOP)
word1 = Label(frame2, text="", bg="blue", fg="white")
word1.pack(side=TOP)
button2 = Button(frame2, text="Launch: Divinity Original Sins 2", bg="dark orange", fg="dark red", command=launch1)
button2.pack(side=BOTTOM)



root.mainloop()